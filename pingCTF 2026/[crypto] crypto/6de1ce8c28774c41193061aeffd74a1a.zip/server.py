import json
import hashlib
import sys
from Crypto.Cipher import AES
import ECDH

def get_flag():
    try:
        with open("flag.txt", "rb") as f:
            return f.read().strip()
    except FileNotFoundError:
        return b"fake_flag_for_testing"

def main():
    # Initialize connection and encrypt the flag
    flag = get_flag()
    b_priv = ECDH.generate_private_key()
    
    
    aes_key = hashlib.sha256(str(b_priv).encode()).digest()
    cipher = AES.new(aes_key, AES.MODE_CTR)
    nonce = cipher.nonce
    ciphertext = cipher.encrypt(flag)
    
    
    print("=== Welcome to the Curveball server ===")
    print("Here is your encrypted flag. Good luck!")
    print(f"Data (hex): {(nonce + ciphertext).hex()}")
    print("=======================================\n")
    
    
    while True:
        try:
            print("Enter your public point R_A in JSON format [x, y]:")
            sys.stdout.flush() 
            
            req = input()
            if not req:
                break
                
            R_A_list = json.loads(req)
            if len(R_A_list) != 2:
                print("Error: Expected [x, y]")
                continue
                
            R_A = (int(R_A_list[0]), int(R_A_list[1]))
            
        
            shared_secret, R_B = ECDH.ecdh_responder(R_A, b_priv)
            
            
            mac = hashlib.sha256(shared_secret).hexdigest()
            print(f"MAC: {mac}")
            
        except ValueError:
            print("ValueError: Invalid point or mathematical error.")
        except Exception as e:
            print(f"Critical error: {e}")
            break

if __name__ == "__main__":
    main()
