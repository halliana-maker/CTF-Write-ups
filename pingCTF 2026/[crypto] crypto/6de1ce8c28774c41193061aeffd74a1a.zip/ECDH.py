from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from secrets import randbelow
from typing import Optional, Tuple

Point = Optional[Tuple[int, int]]  # None means point at infinity


@dataclass(frozen=True)
class Curve:
    p: int          # field prime
    a: int          # curve coefficient a
    b: int          # curve coefficient b
    G: Tuple[int, int]  # generator point
    n: int          # order of G
    h: int = 1      # cofactor


# NIST P-192
NIST_P192 = Curve(
    p = 6277101735386680763835789423207666416083908700390324961279,
    a = -3,
    b = 0x64210519e59c80e70fa7e9ab72243049feb8deecc146b9b1,
    G = (
        0x188da80eb03090f67cbf20eb43a18800f4ff0afd82ff1012,
        0x07192b95ffc8da78631011ed6b24cdd573f977a11e794811,
    ),
    n = 6277101735386680763835789423176059013767194773182842284081,
)


def point_neg(P: Point, curve: Curve = NIST_P192) -> Point:
    if P is None:
        return None
    x, y = P
    return (x, (-y) % curve.p)


def point_add(P: Point, Q: Point, curve: Curve = NIST_P192) -> Point:
    p = curve.p

    if P is None:
        return Q
    if Q is None:
        return P

    x1, y1 = P
    x2, y2 = Q

    # P + (-P) = O
    if x1 == x2 and (y1 + y2) % p == 0:
        return None

    if P == Q:
        # tangent slope for doubling
        if y1 == 0:
            return None
        m = (3 * x1 * x1 + curve.a) * pow(2 * y1, -1, p) % p
    else:
        # chord slope for addition
        m = (y2 - y1) * pow(x2 - x1, -1, p) % p

    x3 = (m * m - x1 - x2) % p
    y3 = (m * (x1 - x3) - y1) % p
    return (x3, y3)


def scalar_mult(k: int, P: Point, curve: Curve = NIST_P192) -> Point:
    """Double-and-add scalar multiplication."""
    if k % curve.n == 0 or P is None:
        return None
    if k < 0:
        return scalar_mult(-k, point_neg(P, curve), curve)

    result: Point = None
    addend: Point = P

    while k:
        if k & 1:
            result = point_add(result, addend, curve)
        addend = point_add(addend, addend, curve)
        k >>= 1

    return result


def ecdh_sender_public(
    a_priv: int,
    curve: Curve = NIST_P192,
) -> Tuple[int, int]:

    if not (1 <= a_priv < curve.n):
        raise ValueError("Invalid private key scalar.")

    R_A = scalar_mult(a_priv, curve.G, curve)
    if R_A is None:
        raise RuntimeError("Failed to compute R_A.")

    return R_A


def ecdh_responder(
    R_A: Tuple[int, int],
    b_priv: int,
    curve: Curve = NIST_P192,
) -> tuple[bytes, Tuple[int, int]]:

    if not (1 <= b_priv < curve.n):
        raise ValueError("Invalid private key scalar.")

    R_B = scalar_mult(b_priv, curve.G, curve)
    if R_B is None:
        raise RuntimeError("Unexpected failure computing public key.")

    S = scalar_mult(b_priv, R_A, curve)
    if S is None:
        raise ValueError("Shared point is at infinity; invalid peer public key.")

    x_shared, _ = S

    # Convert x-coordinate to a fixed-length byte string and hash it
    byte_len = (curve.p.bit_length() + 7) // 8
    shared_secret = sha256(x_shared.to_bytes(byte_len, "big")).digest()

    return shared_secret, R_B


# Optional helper for generating B's private key
def generate_private_key(curve: Curve = NIST_P192) -> int:
    return randbelow(curve.n - 1) + 1